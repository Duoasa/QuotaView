# QuotaView 开发交接入口

更新日期：2026-09-13。本目录是旧实验 checkout，当前开发在 `.worktrees/` 中。

## 当前开发

请阅读唯一的[开发 Handoff](.worktrees/QuotaView-0.4.8/HANDOFF.md#工作区与版本定位)：
那里区分开发源码、已运行构建、未打包修复及验收状态。目录名不代表当前版本。

- [当前 SDD 注册表](.worktrees/QuotaView-0.4.8/docs/specs/README.md)
- [工作区执行规则](.worktrees/QuotaView-0.4.8/AGENTS.md)
- [公开稳定版与发布历史](.worktrees/QuotaView-0.4.8/VERSION_HISTORY.md#当前最新版本)

本入口只负责路由，不复制版本号；更换开发工作区时同步本页与根 AGENTS.md。
开始修改前核对 `git worktree list` 和目标工作区的 Git 状态，保留未提交工作。

## 历史交接

[2026-08-10 旧根 checkout Handoff](docs/archive/root-handoff-2026-08-10.md)
保留当时 0.3.1 实验分支的过程；其中的下一步不再作为当前开发任务。
