# QuotaView 多工作区入口

此目录包含旧实验 checkout 和 `.worktrees/` 中的后续开发工作区。
根目录 README、Handoff 和版本历史只作导航；原内容已归档。旧 checkout 的
源码版本号和设计记录不能代表当前开发状态。

- 用户明确指定工作区或历史版本时，按指定范围工作。
- 继续当前 QuotaView 开发或维护 SDD 时，从
  [开发 Handoff](.worktrees/QuotaView-0.4.8/HANDOFF.md) 定位开发最新版，并读取
  [工作区 AGENTS.md](.worktrees/QuotaView-0.4.8/AGENTS.md)。此处是可更新的入口
  指针；修改前用 `git worktree list` 和目标目录的 `git status --short --branch`
  核对实时状态，不用目录名判断版本。
- 公开稳定版由目标工作区的 `VERSION_HISTORY.md#当前最新版本` 定位。
  开发代码可能更新，即使暂时沿用相同版本配置；保留未发布修改。
- 一般问答、文章解释和已定位的小文档修复直接处理相关内容，不读取全套项目文档。
- 明确维护根 checkout 时才按需查阅[旧分支规则](docs/archive/root-checkout-rules.md)；
  其中的“当前版本”属于历史记录。

保留未提交工作、用户文件与设备数据；不擅自切分支、reset、clean、提交、
推送、发布、替换安装或改变版本身份。已有授权在同一范围内持续有效；完成
相关编辑和必要本地验证，不为同一范围重复确认。签名、公证、发布和 appcast
遵循目标工作区的精确版本授权规则。真实额度重置保持演示；视觉验收由用户完成。
