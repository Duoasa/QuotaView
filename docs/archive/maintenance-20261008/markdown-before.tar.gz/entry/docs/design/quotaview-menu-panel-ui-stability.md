# QuotaView 菜单面板 UI 跳动修复方案

## 1. 文档定位

| 项目 | 内容 |
|---|---|
| 状态 | 已实现并通过产品所有者手动验收 |
| 复核日期 | `2026-08-16`（Asia/Shanghai） |
| 复核代码 | `origin/main` / `d3487bd20435ce6b6041423431672d4764c36d98` |
| 首次稳定版本 | `0.3.3 (Build 3)` |
| 当前生产基线 | `0.3.5 (Build 5)` 继续沿用 |
| 对应规格 | `QV-PRODUCT-TOKEN-ACTIVITY-001` |
| 主要场景 | Token 活动图表在周、月、三个月和最长范围之间切换 |
| 核心目标 | 面板顶部固定，仅底边平滑伸缩；内容不先跳动再回位 |

本文记录 2026-08-10 至 2026-08-11 对菜单面板 UI 跳动问题的完整
诊断、迭代和最终方案。这里的“跳动”主要指 Token 活动范围切换导致方格
行数和菜单高度变化时，Header、上方额度数据或整个面板出现瞬时上下位移。

这不是单纯的 SwiftUI 动画问题，也不是只靠固定 `NSPanel` 坐标就能解决的
问题。最终方案同时约束了 SwiftUI 状态、内容测量、AppKit 窗口几何、承载
视图布局和状态提交顺序。

## 2. 最终结论

最终采用的方案可以概括为：

1. 使用语义稳定的行 ID，避免数据刷新把已有内容误判成删除后重建；
2. 将 Hover 延迟任务移出方格自身的视图状态，Tooltip 只保留一个图表级
   浮层；
3. 周期状态更新关闭隐式动画，并忽略重复选择；
4. 由 AppKit 统一负责面板几何，始终以菜单栏下方的固定顶边计算窗口；
5. SwiftUI 根内容和 AppKit 承载视图同时锁定到顶部，动态高度只影响底部；
6. 面板高度变化使用固定顶边的 `0.14 s` ease-out 自定义插值，连续切换从
   当前帧接续；
7. **向下扩展前先计算目标高度并让 AppKit 准备承载区域，再提交 SwiftUI
   周期状态。**这是消除最后一帧扩展跳动的关键；
8. Reduce Motion 下跳过过渡，直接一次性提交最终顶部锚定 Frame。

产品所有者最终确认 Build 13 的周、月、三个月及最长范围双向切换不再
跳动。该实现随后合并进 `0.3.3 Build 3`，并继续存在于 `0.3.5 Build 5`。

## 3. 问题表现

### 3.1 用户可见症状

- 切换到行数更多的图表时，上方 Header 和指标会先向上或向下闪动；
- 面板高度最终是正确的，但中间会出现一帧内容挤压、重排或整体回位；
- 收缩和扩展的表现不对称：收缩较稳定，扩展仍可能突然跳一下；
- 快速连续切换范围时，旧动画和新目标互相覆盖，视觉节奏不连续；
- Hover Tooltip 出现或取消时，方格局部状态更新可能放大整个图表的重算；
- 固定延迟调整窗口时，新图表会先在旧窗口高度内渲染若干帧。

### 3.2 已排除的错误判断

窗口采样表明，问题后期已经不是菜单栏锚点漂移，也不是计算出了多个错误
的中间目标高度。面板顶边和水平位置可以保持正确，用户仍然会看到内容
跳动。真正剩余的问题是：

- `NSHostingView` 在高度变化时会重新布局根内容；
- 承载视图曾跟随窗口高度自动缩放，固定高度内容会围绕新的可用区域重新
  分布；
- 扩展时，较大的 SwiftUI 图表可能先进入旧的较小承载区域一帧；
- 窗口边界动画和内容状态提交不是同一个有序事务。

因此，“窗口最终 Frame 正确”并不等于“中间每一帧的内容位置稳定”。

## 4. 根因分层

| 层级 | 根因 | 用户看到的结果 |
|---|---|---|
| SwiftUI 身份 | 动态行或方格没有稳定语义身份时，刷新会触发删除/插入 | 行闪烁、局部状态丢失、内容重建 |
| Hover 状态 | 每个方格持有延迟任务和动态 overlay | Hover 触发额外布局和过期 Tooltip |
| 动画事务 | 周期按钮的按压动画与网格重排处于同一事务 | 内容尺寸变化被意外动画化 |
| 测量时序 | 使用固定 `40 ms` 延迟更新窗口 | 新内容先在旧窗口内出现 2–3 帧 |
| 窗口几何 | 先 `setContentSize`，再二次调整位置 | WindowServer 可显示一次错误中间 Frame |
| 承载布局 | `NSHostingView` 高度跟随窗口并重新布局 | 顶部内容在动画中发生中线式位移 |
| 扩展顺序 | 先提交大网格，后扩大承载区域 | 新内容进入小区域的一帧造成跳动 |

## 5. 必须保持的布局不变量

任何后续重构都必须保持以下不变量：

1. 面板顶边恒定：`frame.maxY = screen.visibleFrame.maxY - menuBarGap`；
2. 面板宽度和水平锚点在纯高度切换中不变化；
3. 高度变化只能移动底边：`origin.y = fixedTop - height`；
4. Header 和已有上方内容始终贴住承载视图顶部；
5. 承载内容的目标高度独立于当前窗口裁切高度；
6. 扩展时必须先准备目标高度，再插入更大的 SwiftUI 内容；
7. 收缩时允许先改变内容，再由底部向上裁切；顶部内容不得参与位移；
8. 同一目标 Frame 不重复启动动画；
9. 新目标到来时从当前显示帧接续，不跳回旧动画起点；
10. Reduce Motion 下不执行插值，但仍保持同一顶部锚定结果。

## 6. 最终状态流

```mermaid
flowchart TD
    A["用户选择新的 Token 范围"] --> B["根据目标范围构建纯数据 GridModel"]
    B --> C["提前计算目标菜单内容高度"]
    C --> D{"目标高度是否更大"}
    D -- 是 --> E["同步调用 prepareContentExpansion"]
    E --> F["AppKit 设置目标承载高度并启动底边扩展"]
    D -- 否 --> G["无需扩展预准备"]
    F --> H["无动画 Transaction 提交范围状态"]
    G --> H
    H --> I["SwiftUI 生成新网格"]
    I --> J["下一次主循环合并 fittingSize 测量"]
    J --> K["忽略重复目标或从当前帧接续"]
    K --> L["固定顶边，仅平滑移动底边"]
```

关键点是 `E → F → H` 的顺序。若改成先执行 `H`，较大的网格可能在 AppKit
承载区尚未扩展时出现一帧，这正是 Build 12 仍未完全解决的残余跳动。

## 7. 具体实现

### 7.1 使用稳定语义 ID

`QuotaViewFigmaMenu.PanelItem` 为每个区域提供固定 ID，例如：

- `usage-summary`
- `spark-quota-summary`
- `credits-balance`
- `today-tokens`
- `thirty-day-tokens`
- `lifetime-tokens`
- `estimated-cost`
- `token-activity`
- `quota-reset`

列表使用元素自身的语义 ID，而不是临时 UUID 或随刷新变化的展示值。
额度值、Token 数值或倒计时变化时，SwiftUI 会更新原有行，而不是把它当作
新行重新插入。这一层主要防止“数据刷新型跳动”，但它本身不足以解决范围
切换引起的窗口高度变化。

图表方格在同一范围内使用可预测的位置 ID；范围模型变化时主动取消旧
Tooltip，避免悬停状态附着到已经变化的单元。

### 7.2 隔离 Hover 与 Tooltip 状态

原方案为每个方格维护 Hover 状态、延迟任务和动态 overlay。修复后：

- `TokenActivityHoverController` 独立维护 `hoveredCellID` 和延迟任务；
- 控制器没有 `@Published` 字段，单纯开始或取消计时不会发布视图更新；
- 图表只保留一个 `tooltipPresentation`；
- Tooltip 放在整个网格的顶层 `ZStack`，不参与单个方格的布局；
- Tooltip 使用 `.allowsHitTesting(false)`，避免浮层触发新的 Hover 循环；
- 模型改变或图表消失时取消任务并清空展示。

这一层消除了 Hover 带来的无关重排，也保证取消后的异步任务不会延迟弹出
过期 Tooltip。

### 7.3 周期切换关闭隐式动画

周期按钮处理遵循以下逻辑：

```swift
guard currentRange != targetRange else { return }

let targetHeight = menuHeight(for: targetRange)
if targetHeight > currentHeight {
    prepareContentExpansion(targetHeight)
}

var transaction = Transaction(animation: nil)
transaction.disablesAnimations = true
withTransaction(transaction) {
    currentRange = targetRange
}
```

这里有三个目的：

1. 重复点击当前范围不会制造无意义的布局周期；
2. 按钮的 Pressed 动画不会把网格重排带进同一动画事务；
3. 扩展预准备一定发生在范围状态更新之前。

### 7.4 由 AppKit 统一计算面板 Frame

`MenuBarPanelGeometry.anchoredFrame` 是窗口几何的单一入口：

```text
x = clamp(anchorCenterX - width / 2, screenLeftInset, screenRightInset)
y = visibleFrame.maxY - height - menuBarGap
```

面板可见时不再先调用 `setContentSize`、随后再调整原点，而是：

1. 从目标内容大小换算完整 Window Frame；
2. 通过顶部锚点计算最终原点；
3. 使用一次 `setFrame` 提交当前动画帧。

这避免 WindowServer 在两个 API 调用之间显示“尺寸已变但位置尚未回正”的
中间状态。面板不可见时可以直接设置内容尺寸，因为此时没有可见中间帧。

### 7.5 下一主循环立即合并测量

所有会影响布局的 Store 或 Preferences 变化仍会触发重新测量，但调度方式
由固定 `40 ms` 延迟改为：

1. 取消尚未执行的旧 `DispatchWorkItem`；
2. 在下一次主线程循环执行一次 `resizePanelToFit`；
3. 先让 `NSHostingView` 完成布局，再读取 `fittingSize`；
4. 对高度向上取整，交给唯一的 AppKit Resize 路径。

这样既可以合并同一轮中的多次状态变化，又不会让 SwiftUI 新内容在旧窗口
中停留多个可见帧。

### 7.6 固定顶边的自定义底边动画

窗口变化不依赖 AppKit 系统动画，而是使用自定义计时器：

- 时长：`0.14 s`；
- 目标帧率：`120 Hz`；
- 缓动：`easeOutCubic`，即 `1 - (1 - progress)^3`；
- 每帧高度插值；
- 每帧重新计算 `y = fixedTop - interpolatedHeight`；
- 动画结束时精确提交目标 Frame；
- 新目标到来时取消旧计时器，以当前面板 Frame 作为新起点；
- Reduce Motion 开启时直接设置目标 Frame。

这种方式不让系统自行决定窗口原点，能够保证每一帧的 `maxY` 都相同。

### 7.7 SwiftUI 根内容锁定顶部

窗口顶边固定仍不够，根内容也必须固定。`MenuBarPanelRoot` 使用：

```swift
VStack(spacing: 0) {
    MenuBarView(...)
    Spacer(minLength: 0)
}
.frame(maxHeight: .infinity, alignment: .top)
```

同时不再依赖根视图的垂直 `fixedSize` 去驱动整个承载区域。这样窗口变高或
变矮时，真实菜单内容保持贴顶，新增空间只出现在底部。

### 7.8 AppKit 承载视图使用独立内容高度

玻璃 Surface 同时覆盖 macOS 26 Liquid Glass 和 macOS 14–15 Legacy
Material，两条路径都遵循同一规则：

- 背景玻璃继续填满窗口 bounds；
- `NSHostingView` 的 autoresizing 只保留宽度，不自动跟随窗口高度；
- Surface 单独保存 `hostedContentHeight`；
- 承载内容按目标高度固定在顶部；
- 当前窗口较小时，由窗口底部裁切尚未露出的内容。

坐标处理分别为：

- flipped 的 Liquid Glass 组合视图：内容 `y = bounds.minY`；
- Legacy AppKit 视图：内容 `y = bounds.maxY - contentHeight`。

这解决了 Build 10 中“窗口边界已经平滑，但内容仍围绕中线重新布局”的
问题。

### 7.9 扩展前预准备

这是最终通过验收的关键修复。

当目标范围需要更多行时，SwiftUI 在改变 `tokenActivityRange` 之前：

1. 使用目标范围构建不会修改状态的 `TokenActivityGridModel`；
2. 根据目标 `rowCount` 计算图表区高度；
3. 汇总 Header、主额度、Spark、普通指标、成本图、重置入口和 Footer，
   得到目标菜单高度；
4. 同步调用 `prepareContentExpansion(targetHeight)`；
5. AppKit 设置 `hostedContentHeight` 并建立窗口扩展目标；
6. 最后才在无动画 Transaction 中提交范围状态。

此时新网格虽然已经拥有更大的目标内容高度，但窗口会从底部逐步把它露出，
Header 和已有内容始终停留在原位置。

收缩不需要同样的预准备：内容先变小后，顶部锁定布局仍然稳定，窗口只需
从底部向上收回多余空间。

## 8. 迭代过程与为什么前序方案不够

| 迭代 | 处理内容 | 结果 |
|---|---|---|
| Build 7 | 一次性计算尺寸和菜单栏锚点，避免 `setContentSize` 后二次回位 | 排除明显的窗口双跳，但内容仍可能跳动 |
| Build 8 | Hover 控制器独立化、单一 Tooltip 浮层、范围更新关闭隐式动画 | 减少无关重排，但高度切换仍可见跳动 |
| Build 9 | 移除固定 `40 ms` 延迟，下一主循环同步窗口尺寸 | 消除 2–3 帧旧窗口，但单帧内容跳动仍存在 |
| Build 10 | 顶边固定，窗口高度和原点在 `0.14 s` 内 ease-out | 窗口边界平滑，承载内容仍向上移动 |
| Build 11 | SwiftUI 根内容和 AppKit 承载视图都锁定顶部 | 收缩稳定，向下扩展仍会跳一下 |
| Build 12 | 放弃系统窗口插值，改为逐帧固定顶边、仅移动底边 | 排除系统动画因素，扩展首帧问题仍存在 |
| Build 13 | 先预计算并准备扩展目标，再提交大网格状态 | 双向切换通过产品所有者验收 |

Build 10–13 是连续的本地验收迭代，没有分别创建公开 Release 或独立 tag；
最终实现集中进入 `0.3.3 Build 3`。

## 9. 当前代码映射

| 职责 | 文件 / 符号 |
|---|---|
| 顶部锚定 Frame | `Sources/QuotaView/MenuBarPanelController.swift` / `MenuBarPanelGeometry.anchoredFrame` |
| 合并重新测量 | 同文件 / `scheduleResize`、`resizePanelToFit` |
| 内容高度与窗口目标 | 同文件 / `resizePanel(toContentHeight:)` |
| 固定顶边动画 | 同文件 / `animatePanelBottomEdge`、`advancePanelResizeAnimation` |
| 顶部锁定 SwiftUI 根视图 | 同文件 / `MenuBarPanelRoot` |
| Liquid Glass 承载高度 | 同文件 / `QuotaViewGlassCompositionView.setHostedContentHeight` |
| Legacy 承载高度 | 同文件 / `QuotaViewLegacyGlassSurface.setHostedContentHeight` |
| 目标高度预计算 | `Sources/QuotaView/QuotaViewFigmaMenu.swift` / `menuHeight(for:)` |
| 扩展前预准备 | 同文件 / `tokenActivityRangeButton` |
| 稳定区域 ID | 同文件 / `PanelItem.id`、`Metric.id` |
| Hover 隔离 | 同文件 / `TokenActivityHoverController`、`TokenActivityHeatmap` |
| 回调传递 | `Sources/QuotaView/MenuBarView.swift` / `prepareContentExpansion` |
| 几何与 Hover 测试 | `Tests/QuotaViewCoreTests/AppBehaviorTests.swift` |

关键历史提交：

- `f626aac`：首次稳定周期切换的窗口锚点；
- `8a1d3ad`：隔离 Token 图表 Hover 状态；
- `df455a8`：同步图表与窗口 Resize；
- `dfed458`：整合顶部承载、底边动画和扩展前预准备；
- `a93a81a`：合并 `0.3.3 Token Activity` 到生产线。

## 10. 验证方案

### 10.1 自动化测试

至少保留并扩展以下测试：

1. 不同高度的面板拥有相同 `maxY`；
2. 水平位置在纯高度切换中不变；
3. 取消 Hover 延迟任务后不会展示 Tooltip；
4. 新 Hover 任务可以正常展示对应单元；
5. 重复目标 Frame 不启动第二个 Resize；
6. 快速连续目标从当前 Frame 接续；
7. Reduce Motion 直接得到最终顶部锚定 Frame；
8. `menuHeight(for:)` 与目标范围的网格行数一致；
9. 扩展路径先调用预准备，再发布范围变化；
10. 数据刷新后稳定 PanelItem ID 不变化。

当前已有自动化覆盖顶部锚点与 Hover 取消；第 5–10 项适合在后续抽取更纯的
Resize 状态机时补充。

### 10.2 手动验收矩阵

| 维度 | 场景 |
|---|---|
| 范围 | 周 → 月 → 三个月 → 半年，以及完全反向 |
| 连续操作 | 快速往返、动画中再次点击、重复点击当前范围 |
| 数据 | 有数据、无数据、刷新中、刷新成功、刷新失败 |
| 内容开关 | Token 图表、Spark、成本图、普通指标、重置入口组合 |
| 外观 | 深色、浅色、跟随系统 |
| 材质 | 磨砂、清透 |
| 动效 | Reduce Motion 开 / 关 |
| 屏幕 | 主屏、副屏、靠近左右边缘的状态栏入口 |
| Hover | 动画前、动画中、动画后进入和移出方格 |

验收标准：

- Header、主额度标题和上方指标在所有帧中位置稳定；
- 面板 `maxY` 始终等于固定菜单栏锚点；
- 只有底边移动；
- 不出现旧高度承载新网格的一帧；
- 不出现过期 Tooltip；
- 连续切换无回弹、无跳回旧起点；
- Reduce Motion 下没有插值动画，但没有布局跳动。

## 11. 回归门禁

后续修改动态面板时不得：

- 恢复“先 `setContentSize`、后调整原点”的两阶段可见更新；
- 恢复固定毫秒延迟来等待 SwiftUI 布局；
- 让 `NSHostingView` 同时自动跟随窗口宽度和高度；
- 移除 SwiftUI 根视图的顶部对齐；
- 在提交更大内容后才准备窗口扩展；
- 使用随机 UUID 或展示值作为稳定区域 ID；
- 为每个方格恢复独立的 Tooltip overlay 和延迟任务；
- 把网格重排放入按钮 Pressed 或默认 SwiftUI 动画事务；
- 在 Reduce Motion 开启时继续播放窗口 Resize 动画；
- 只检查最终 Frame，而不检查中间帧的内容位置。

## 12. 新动态区域的复用模板

未来增加会改变菜单高度的区域时，应复用同一模式：

1. 用纯函数根据目标状态计算内容模型；
2. 用纯函数计算目标高度，不依赖状态已经提交；
3. 如果目标更高，先调用 AppKit 预准备；
4. 在禁用布局隐式动画的 Transaction 内更新业务状态；
5. 下一主循环重新测量并合并重复目标；
6. 用固定顶边 Resize 只移动底边；
7. 让承载内容保持目标高度并贴顶，由窗口底部负责裁切；
8. 为区域和行提供稳定语义 ID；
9. 将 Hover、延迟任务和浮层从单元布局中隔离；
10. 同时验证扩展、收缩、快速反向和 Reduce Motion。

## 13. 方案边界

本方案解决的是动态内容和 `NSPanel` 高度变化造成的布局跳动，不应被用于
掩盖错误业务状态或伪造固定高度。数据缺失时仍应按真实显示规则隐藏区域，
面板也必须按可见内容动态缩短。

当前 `120 Hz Timer` 在既有体量下满足产品验收。若未来面板包含更重的实时
绘制，可评估抽取独立 Resize 状态机并使用显示同步机制；在没有性能证据前，
不应为了“更高级的动画”替换当前已经稳定的固定顶边方案。
