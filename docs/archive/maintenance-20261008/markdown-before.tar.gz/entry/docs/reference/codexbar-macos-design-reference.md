# CodexBar macOS 实现拆解与 QuotaView 设计参考

> 文档编号：`QV-REF-CODEXBAR-001`
>
> 分析对象：[`steipete/CodexBar`](https://github.com/steipete/CodexBar)
>
> 固定源码基线：[`dd029db4cb17811edd5805d952c5d5fc23395be3`](https://github.com/steipete/CodexBar/commit/dd029db4cb17811edd5805d952c5d5fc23395be3)
>
> 基线时间：2026-07-28
>
> 文档创建时间：2026-07-28
>
> 适用项目：QuotaView 0.1.5 Build 6 及后续演进
>
> 文档性质：架构与实现参考，不是 QuotaView 视觉规范的替代品

## 0. 如何使用这份文档

这份文档将 CodexBar 的 macOS 实现拆成稳定的“学习单元”。后续可以直接
对 Codex 说：

- “按 `CB-CODEX-02` 学习 OAuth 用量获取，但不要读取 QuotaView 用户凭据。”
- “按 `CB-REFRESH-03` 给 QuotaView 增加防止旧请求覆盖新状态的机制。”
- “只参考 `CB-MENUBAR-01` 的状态栏持久化，不改变 QuotaView 面板设计。”
- “比较 `CB-SEC-02` 与 QuotaView 当前 App Server 通信的安全边界。”

每个学习单元都包含：

1. CodexBar 的真实实现；
2. 对应源码入口；
3. 设计价值与代价；
4. QuotaView 应采用、改造或拒绝的结论。

### 0.1 证据优先级

本文按以下优先级判断 CodexBar 的真实行为：

1. 固定提交中的生产源码；
2. 同一提交中的测试；
3. 同一提交中的项目文档；
4. README 和发布说明。

源码与文档冲突时，以源码为准。例如固定提交的 Codex `auto` 数据源实际
顺序是 **OAuth → CLI**，而 `docs/codex.md` 的部分文字仍描述旧的
Web → CLI 行为。本文采用源码行为，并单独记录这种文档漂移。

### 0.2 分析边界

本文详细分析：

- macOS 应用生命周期和菜单栏实现；
- 状态、设置、Provider、刷新、缓存和并发控制；
- Codex OAuth、HTTP、CLI App Server、PTY、WebKit 等数据路径；
- 网络接口、JSON-RPC 方法、安全与错误策略；
- Widget、CLI、辅助进程、构建、签名和测试；
- 对 QuotaView 的可执行借鉴建议。

本文不会逐个抄录 63 个 Provider 的所有私有或半公开接口。多 Provider
部分重点分析它们共享的框架，并用代表性数据源说明扩展方式。接口可能随
上游服务改变，实现前必须重新核对当前源码和服务条款。

---

## 1. 结论摘要

CodexBar 的成熟度主要来自四件事，而不是菜单卡片本身：

1. **数据源策略化**：OAuth、CLI、Web、API、Local Probe 都被包装成
   可排序、可检测、可追踪、可决定是否回退的 Fetch Strategy。
2. **异步结果有发布资格**：请求不仅要成功，还必须证明自己仍属于当前
   Provider、当前账号、当前配置修订和当前 generation，才能写入 UI。
3. **失败不等于清空数据**：取消、超时、断网、临时服务器错误与“确实
   没有可用额度”是不同状态；旧快照可保留并标记 stale。
4. **菜单栏按长期运行优化**：稳定的 `NSStatusItem.autosaveName`、
   图标缓存、变化签名、菜单行复用、延迟刷新和受约束的后台任务，避免
   菜单栏应用持续耗电或跳动。

对 QuotaView 最有价值的不是照搬 CodexBar 的 63 Provider 和复杂菜单，
而是吸收以下可靠性设计：

- 为当前 App Server 请求增加 generation/config/account 发布守卫；
- 将刷新状态拆成 valid、refreshing、stale、known-unavailable、
  transient-error；
- 对可选数据采用独立、短超时、best-effort enrichment；
- 对 Schema 变化采用可损解码、未知枚举和数据可信度标记；
- 对网络路径使用临时 Session、同源 HTTPS 重定向约束和安全重试；
- 把刷新策略写成纯函数并用虚拟时钟测试；
- 保留 QuotaView 现有 `NSPanel + 单层 Liquid Glass + 固定设计令牌`。

---

## 2. 项目规模、技术栈与功能范围

### 2.1 固定提交下的规模快照

以下数据由固定提交源码本地统计，仅用于理解复杂度，不是质量指标：

| 范围 | Swift 文件 | Swift 行数 |
|---|---:|---:|
| `Sources/CodexBar` | 392 | 79,854 |
| `Sources/CodexBarCore` | 476 | 130,246 |
| `Sources/CodexBarCLI` | 33 | 12,274 |
| `Sources/CodexBarWidget` | 6 | 3,087 |
| `Tests` | 661 | 235,044 |
| `TestsLinux` | 34 | 4,395 |

测试源码中约有 7,223 个 `func test` 或 `@Test` 匹配项。它说明该项目把
Provider 兼容性、解析和并发边界视作核心产品能力。

`UsageProvider` 在固定提交中有 63 个 case，覆盖 Codex、Claude、
OpenAI、Cursor、Gemini、GitHub Copilot、OpenRouter、Ollama、Bedrock、
DeepSeek、Mistral 等服务。

### 2.2 技术栈

| 项目 | CodexBar 实现 |
|---|---|
| 语言 | Swift 6，Swift tools 6.2 |
| 最低系统 | macOS 14 |
| UI | SwiftUI + AppKit |
| 状态 | Observation `@Observable`，主状态 `@MainActor` |
| 并发 | Swift Concurrency、actors、TaskGroup、显式取消 |
| 包管理 | SwiftPM；Widget 另由 Xcode project 构建 |
| 更新 | Sparkle |
| 快捷键 | KeyboardShortcuts |
| Cookie | SweetCookieKit |
| 加密 | swift-crypto |
| 日志 | swift-log + OSLog 后端 |
| CLI | Commander |

主要依赖和 target 定义见
[`Package.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Package.swift)。

### 2.3 用户侧功能

CodexBar 不只是一个额度菜单，固定提交包含：

- 单 Provider 或多 Provider 菜单栏项目；
- 合并图标、Provider 切换和多账号切换；
- 会话、周/月额度、Credits、消费、成本和历史趋势；
- Provider 状态页事故提示；
- 自适应刷新、固定刷新、手动刷新；
- 配额警告、重置通知和系统通知；
- CLI 只读查询及机器可读输出；
- WidgetKit 桌面/通知中心组件；
- Launch at Login；
- Sparkle 自动更新；
- Provider 登录与 Cookie/OAuth/API Key 配置；
- Codex 本地 session 成本估算；
- 调试探针、WebKit 探针和 Claude 子进程 watchdog。

这些能力形成一个“多数据源状态聚合平台”。QuotaView 当前是专注 Codex
的紧凑工具，不应因参考它而自然演变成同等规模的平台。

---

## 3. 总体架构

### 3.1 Target 和责任边界

```mermaid
flowchart TB
    APP["CodexBar macOS App<br/>生命周期、状态、菜单、设置"]
    CORE["CodexBarCore<br/>Provider、模型、传输、解析、CLI/OAuth"]
    CLI["CodexBarCLI<br/>命令行查询与输出"]
    WIDGET["CodexBarWidget<br/>App Group 快照读取"]
    ADAPT["AdaptiveRefreshCore<br/>纯刷新策略"]
    REPLAY["AdaptiveReplayCLI / Kit<br/>离线回放和策略审计"]
    WATCH["Claude Watchdog<br/>孤儿进程清理"]
    PROBE["Claude Web Probe<br/>诊断辅助"]

    APP --> CORE
    APP --> ADAPT
    APP --> WIDGET
    CLI --> CORE
    REPLAY --> ADAPT
    APP --> WATCH
    APP --> PROBE
```

#### `CodexBarCore`

跨平台、尽量不依赖 AppKit 的核心层，主要包含：

- `UsageProvider`、Provider metadata 和 descriptor；
- `ProviderFetchContext`、Strategy、Pipeline、Outcome；
- HTTP client、重定向、Cookie、Keychain 和配置工具；
- Provider 的 OAuth/API/CLI/本地文件解析器；
- Codex App Server RPC、PTY 探针和本地成本扫描；
- 共享模型和 Widget snapshot。

#### `CodexBar`

仅 macOS 的应用层，主要包含：

- App 启动和退出清理；
- `SettingsStore`、`UsageStore`；
- Provider app implementation registry；
- `StatusItemController` 和菜单卡片；
- 图标渲染、通知、设置窗口；
- WebKit 生命周期、内存压力和后台调度。

#### `CodexBarCLI`

复用 `CodexBarCore` 的 Fetch Pipeline，并根据命令行 source、Provider、
Credits 等选项创建 Fetch Context。这样 GUI 和 CLI 不需要维护两套解析
逻辑。

#### Widget

主应用把裁剪后的只读 JSON 快照写进 App Group；扩展只读快照，不直接
访问 Provider 凭据或发起完整抓取。

### 3.2 架构原则

CodexBar 的核心依赖方向是：

```text
UI / CLI
  → Store / orchestration
    → Provider descriptor + fetch pipeline
      → transport / process / parser
        → external service or local tool
```

外部响应不会直接驱动 SwiftUI。它必须经过：

1. 传输层；
2. Provider 专属解码和归一化；
3. Provider identity scope；
4. 刷新协调器发布资格检查；
5. `UsageStore`；
6. 菜单卡片和图标模型。

这条路径使单元测试可以在不启动 UI、不访问真实 Keychain、不连接真实
服务的情况下覆盖多数行为。

### 3.3 QuotaView 对照

QuotaView 已有相似的第一层拆分：

```text
QuotaView
├── QuotaViewCore
│   ├── CodexAppServerClient
│   ├── CodexExecutableLocator
│   └── CodexModels
├── QuotaView
│   ├── CodexStatusStore
│   ├── MenuBarPanelController
│   ├── SwiftUI 面板与设置
│   └── AppPreferences
└── QuotaViewProbe
```

因此不需要重构成 CodexBar 的多 Provider 目录。更合适的是在现有
`QuotaViewCore` 和 `CodexStatusStore` 间补齐：

- Fetch result 与错误分类；
- request generation；
- 发布上下文；
- 可选 enrichment；
- 可注入时钟和传输；
- stale/known-unavailable 状态。

---

## 4. 应用入口与生命周期

学习单元：`CB-APP-01`

主入口是
[`CodexbarApp.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/CodexbarApp.swift)。

### 4.1 启动

`@main struct CodexBarApp: App` 使用
`@NSApplicationDelegateAdaptor(AppDelegate.self)`，在 SwiftUI Scene 和
AppKit 生命周期之间建立桥接。

初始化阶段集中创建并连接：

- OSLog 日志后端；
- 版本、Build、Git 时间戳；
- Keychain 访问 gate 和 prompt coordinator；
- 设置存储；
- 语言环境；
- Codex managed account coordinator；
- `UsageFetcher`；
- 浏览器检测；
- `UsageStore`。

App 使用隐藏的极小 `WindowGroup` 维持生命周期，同时提供原生 Settings
Scene。实际菜单栏和窗口控制仍在 AppKit delegate/controller 中完成。

### 4.2 AppDelegate

`AppDelegate` 持有：

- `StatusItemController`；
- Sparkle updater abstraction；
- 重置庆祝效果；
- 内存压力监视；
- 全局快捷键和通知观察者。

应用完成启动后：

1. 确保状态栏 controller 存在；
2. 请求通知权限；
3. 安装全局菜单快捷键；
4. 订阅额度重置相关通知。

应用退出前：

- 停止监视和刷新；
- 关闭菜单与辅助窗口；
- 停止 TTY、RPC 和 Provider 子进程；
- 清理 WebKit/辅助资源。

`LSUIElement` 隐藏 Dock 图标，主入口始终是菜单栏。

### 4.3 QuotaView 建议

QuotaView 当前 AppDelegate 已负责字体注册、Store 启动和
`MenuBarPanelController` 创建。建议只增加明确的对称清理：

- `applicationWillTerminate` 调用 `store.stop()`；
- `CodexStatusStore.stop()` 取消轮询并调用
  `CodexAppServerClient.stop()`；
- 如果以后引入新 Task/Timer/Monitor，统一挂在 Store 或 Controller
  生命周期上。

不需要引入隐藏 WindowGroup 或 CodexBar 的全部启动协调器。

---

## 5. 状态与配置系统

### 5.1 `SettingsStore`

学习单元：`CB-STATE-01`

[`SettingsStore.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/SettingsStore.swift)
是 `@MainActor @Observable` 的大型设置域，并通过 extension 分拆。

它将数据分成两类：

| 数据 | 存储 | 例子 |
|---|---|---|
| 纯 UI 偏好 | `UserDefaults` | 菜单布局、刷新频率、显示选项 |
| Provider 配置 | JSON config | enabled、source、API key、cookie、账号 |

配置路径顺序：

1. `CODEXBAR_CONFIG`；
2. `$XDG_CONFIG_HOME/codexbar/config.json`；
3. `~/.config/codexbar/config.json`；
4. 旧路径 `~/.codexbar/config.json`。

[`CodexBarConfigStore.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/Config/CodexBarConfigStore.swift)
负责：

- pretty + sorted JSON；
- 原子写入；
- 文件权限 `0600`；
- 忽略未知 Provider；
- 去重；
- 为新增 Provider 补默认配置；
- 兼容旧配置迁移。

写入采用约 350 ms debounce，序列化和文件 I/O 移出 MainActor。

### 5.2 配置修订

CodexBar 不把“配置变更”只看成一个布尔值。它维护：

- 全局 config revision；
- 每 Provider enablement revision；
- 每 Provider config revision；
- 配置 fingerprint；
- 哪些修改影响后台数据，哪些只影响 UI。

异步请求开始时捕获这些值，结束时再比较。配置已改变的旧请求即使成功，
也没有资格覆盖新状态。

### 5.3 `UsageStore`

学习单元：`CB-STATE-02`

[`UsageStore.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/UsageStore.swift)
是 `@MainActor @Observable` 的运行时状态中心，持有：

- 每 Provider usage snapshot；
- 错误、诊断、数据源标签、Fetch attempts；
- account snapshot 和 token account；
- Credits、API spend、Dashboard、Storage；
- Provider status incident；
- 版本和可执行文件检测；
- 历史数据；
- 刷新、超时、缓存、WebKit 和通知 Task。

依赖通过初始化器或测试 override 注入，包括 fetcher、registry、history
store、account snapshot store、notifier、environment 和时间相关行为。

### 5.4 显式观察面

CodexBar 为菜单和图标提供较小的 observation token，而不是让
`StatusItemController` 因 Store 任意字段变化都重建 UI：

- `menuObservationToken`；
- `iconObservationToken`。

这是大型状态对象降低重绘成本的重要手段。

### 5.5 QuotaView 建议

QuotaView 的 `AppPreferences` 继续使用 `UserDefaults` 即可。当前只有一个
Provider，也没有凭据配置，不需要 JSON config。

可以借鉴：

- `statusItemPresentationSignature`：仅包含菜单栏实际显示所需字段；
- `panelPresentationSignature`：仅包含面板布局和数据字段；
- generation：每次 refresh 递增；
- preference revision：影响请求或解析的设置变更时递增。

不建议为了“架构一致”引入 63 Provider 的 config schema。

---

## 6. Provider 扩展架构

### 6.1 两层注册表

学习单元：`CB-PROVIDER-01`

CodexBar 有两个互补注册表。

#### Core descriptor registry

[`ProviderDescriptor.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/Providers/ProviderDescriptor.swift)
为每个 `UsageProvider` 注册：

- metadata；
- branding；
- token cost capability；
- Fetch Plan；
- CLI 名称和版本检测。

注册表对 `UsageProvider.allCases` 做完整性检查，缺 descriptor 会触发
precondition。新增 enum case 不能静默遗漏数据层实现。

#### macOS implementation registry

[`ProviderImplementationRegistry.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/Providers/Shared/ProviderImplementationRegistry.swift)
使用穷尽 switch 为每个 Provider 创建 App 实现。

Provider implementation 主要提供“描述数据”：

- presentation；
- availability；
- source label/mode；
- version/runtime；
- 设置字段、开关、picker 和 actions；
- 账号可见性；
- 菜单 entries/actions；
- 登录流程。

宿主统一渲染设置和菜单，而不是让每个 Provider 自由返回任意 SwiftUI。
这保证 63 个 Provider 的行为密度和交互一致。

### 6.2 Fetch Context

学习单元：`CB-PROVIDER-02`

`ProviderFetchContext` 把一次获取所需条件打包，包括：

- runtime：App 或 CLI；
- source mode：auto、web、cli、oauth、api；
- 是否需要 Credits 和可选用量；
- timeout、debug、verbose；
- environment；
- Provider 设置；
- 浏览器检测；
- 选中账号；
- token updater；
- history days；
- CLI session flags。

这样 Strategy 不需要直接依赖全局 App 状态。

### 6.3 Fetch Strategy 与 Pipeline

学习单元：`CB-PROVIDER-03`

[`ProviderFetchPlan.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/Providers/ProviderFetchPlan.swift)
定义：

```swift
protocol ProviderFetchStrategy: Sendable {
    var id: String { get }
    var kind: ProviderFetchKind { get }
    func isAvailable(_ context: ProviderFetchContext) async -> Bool
    func fetch(_ context: ProviderFetchContext) async throws -> ProviderFetchResult
    func shouldFallback(on error: Error, context: ProviderFetchContext) -> Bool
}
```

`ProviderFetchPipeline.fetch` 顺序执行 Strategy：

1. 解析当前 Context 对应的 Strategy 顺序；
2. 检查取消；
3. 调用 `isAvailable`；
4. 记录 unavailable attempt；
5. 执行 fetch；
6. 成功立即返回；
7. 失败记录错误；
8. 只有当前 Strategy 明确允许时才进入下一 Strategy；
9. 取消永不回退。

每次尝试都形成 `ProviderFetchAttempt`，包含 Strategy ID、kind、可用性和
错误摘要。它既方便 Debug，也使 UI 能解释“尝试了什么”。

### 6.4 Provider 数据源类型

CodexBar 将 63 个 Provider 的获取方式归纳为有限种机制：

| 机制 | 典型用途 | 主要风险 |
|---|---|---|
| API key / token | 官方用量、余额、账单 API | 凭据存储、限流 |
| OAuth | 用户已登录 CLI/服务的授权 | token 刷新和账号归属 |
| 浏览器 Cookie | 无公开 API 的 Dashboard | Keychain 提示、会话错配 |
| CLI RPC / PTY | 本地工具已有账号状态 | 进程、超时、Schema 变化 |
| 本地文件/SQLite/XML | 本地 session、成本、配置 | 权限和格式迁移 |
| 本地 HTTP/LSP | IDE 或本地 daemon | 端口发现、版本兼容 |
| WebKit scraping | Dashboard 独有图表 | 高能耗、页面漂移 |
| AWS signed API | Bedrock 类服务 | 签名、区域和账号配置 |

### 6.5 QuotaView 建议

QuotaView 当前只支持 Codex App Server，不需要 Provider registry。

如未来确实增加第二种 Codex 数据源，可先用轻量版本：

```text
CodexSnapshotFetcher
├── AppServerSnapshotFetcher
└── OAuthSnapshotFetcher（只有用户明确同意读取凭据时）
```

保留 `isAvailable/fetch/shouldFallback` 三个行为即可，不要预先引入
branding、settings schema 和跨 Provider 菜单模型。

---

## 7. Codex 数据获取深拆

本节是 QuotaView 最相关的部分。

### 7.1 数据源选择

学习单元：`CB-CODEX-01`

真实选择逻辑在
[`CodexProviderDescriptor.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/Providers/Codex/CodexProviderDescriptor.swift)。

| Runtime | Source mode | Strategy 顺序 |
|---|---|---|
| App | auto | OAuth → CLI |
| App | oauth | OAuth |
| App | cli | CLI |
| App | web | Web Dashboard |
| CLI | auto | OAuth → CLI |
| CLI | oauth | OAuth |
| CLI | cli | CLI |
| CLI | web | Web Dashboard |

重要细节：

- `auto` 并不是“任何错误都切到 CLI”；
- OAuth 只有在 CLI 有能力修复的凭据错误时才 fallback；
- 网络错误、服务错误和解码错误直接返回，避免每次临时网络故障都启动
  `codex app-server`；
- OAuth 成功但缺少特定 monthly credit limit 时，可以在账号身份一致的
  前提下，用 CLI 结果补充该字段。

### 7.2 OAuth 凭据与用量接口

学习单元：`CB-CODEX-02`

主要实现：

- [`CodexOAuthCredentials.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/Providers/Codex/CodexOAuth/CodexOAuthCredentials.swift)
- [`CodexOAuthUsageFetcher.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/Providers/Codex/CodexOAuth/CodexOAuthUsageFetcher.swift)
- [`CodexTokenRefresher.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/Providers/Codex/CodexOAuth/CodexTokenRefresher.swift)
- [`CodexAuthenticatedHTTPTransport.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/Providers/Codex/CodexAuthenticatedHTTPTransport.swift)

凭据来源：

- `$CODEX_HOME/auth.json`；
- 默认 `~/.codex/auth.json`；
- 支持不同版本的 snake_case/camelCase token 字段；
- 部分场景兼容 `OPENAI_API_KEY`。

Token 在 `last_refresh` 缺失或超过约 8 天时视为需要刷新。

#### Token 刷新

| 项目 | 值 |
|---|---|
| Method | `POST` |
| URL | `https://auth.openai.com/oauth/token` |
| Timeout | 30 秒 |
| Content-Type | `application/json` |
| Body | `client_id`、`grant_type=refresh_token`、`refresh_token`、`scope` |
| Scope | `openid profile email` |

刷新结果写回 auth 文件时使用：

- 独占创建的 staging file；
- `0600` 权限；
- flush/fsync；
- 原子 rename；
- 失败时不破坏原文件。

#### 用量获取

| 项目 | 默认值 |
|---|---|
| Method | `GET` |
| URL | `https://chatgpt.com/backend-api/wham/usage` |
| Timeout | 30 秒 |
| Cache | 忽略本地 URL cache |
| Authorization | `Bearer <access token>` |
| User-Agent | `CodexBar` |
| Accept | `application/json` |
| Account header | `ChatGPT-Account-Id`，有 account ID 时发送 |

如果 Codex `config.toml` 设置了 `chatgpt_base_url`：

- backend API 风格 base 使用 `/wham/usage`；
- 其他兼容 base 使用 `/api/codex/usage`。

主要响应字段：

| API 字段 | 归一化用途 |
|---|---|
| `plan_type` | 套餐 |
| `rate_limit.primary_window` | 主周期 |
| `rate_limit.secondary_window` | 次周期 |
| `credits` | Credits 余额 |
| `individual_limit` | 独立消费上限 |
| `additional_rate_limits` | 额外 rate windows |
| `used_percent` | 已使用百分比 |
| `reset_at` | Unix 重置时间 |
| `limit_window_seconds` | 周期长度 |

Plan 类型使用 forward-compatible unknown case，服务端新增套餐不会使整个
响应解码失败。

Primary、secondary 和 additional limits 使用可损解码：单个坏字段或
坏数组元素不会丢掉所有可用窗口，但结果会被标成较低数据可信度。

#### OAuth 回退条件

允许进入 CLI：

- 401/403 unauthorized；
- auth 文件不存在；
- 缺少 token；
- refresh token expired、revoked 或 reused。

不允许自动进入 CLI：

- 普通网络错误；
- 服务端错误；
- 无法解释的响应或解码错误；
- token refresh 的网络错误。

这个策略避免在网络不稳定时产生进程风暴，也保留原始错误语义。

#### 对 QuotaView 的限制

QuotaView 当前隐私承诺是“不读取、复制或保存 `~/.codex` 登录凭据”。
因此不能直接复制 OAuth 路径。只有产品所有者明确改变隐私方向并设计用户
同意流程后，才可以讨论使用它。

目前可学习的是：

- forward-compatible 解码；
- 错误分类；
- 安全落盘方式；
- transport 注入；
- 仅对可修复错误 fallback。

### 7.3 重置 Credits：只读库存

学习单元：`CB-CODEX-03`

CodexBar 的重置 Credit 获取是只读的：

| 项目 | 值 |
|---|---|
| Method | `GET` |
| URL | `https://chatgpt.com/backend-api/wham/rate-limit-reset-credits` |
| Timeout | 4 秒 |
| Authorization | `Bearer <access token>` |
| Accept | `application/json` |
| OpenAI-Beta | `codex-1` |
| originator | `Codex Desktop` |
| Account header | `ChatGPT-Account-ID` |

响应包含：

- `available_count`；
- credits 数组；
- `id`、`reset_type`、`status`；
- `granted_at`、`expires_at`；
- `redeem_started_at`、`redeemed_at`；
- `title`、`description`。

主 App 不让该可选请求阻塞主用量结果：

1. 先完成主 Strategy；
2. 对胜出的结果执行一次 reset credits enrichment；
3. stale OAuth token 不在补充路径刷新，直接跳过；
4. 补充请求失败通常不推翻成功的用量；
5. 新刷新失败时不能继续展示旧的 reset credit 库存；
6. 取消仍然向上传递。

App 侧实现见
[`UsageStore+CodexResetCredits.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/UsageStore%2BCodexResetCredits.swift)。

**固定提交中没有消费或兑换重置 Credit 的实现。**

这与 QuotaView 当前要求完全一致：

- 可以展示真实可用次数；
- 可以演示确认流程；
- 不得调用 `account/rateLimitResetCredit/consume`；
- 不得增加 HTTP consume/redeem 请求。

QuotaView 当前通过 `account/rateLimits/read` 的
`rateLimitResetCredits.availableCount` 获得次数，已经不需要额外读取
OAuth 凭据。可借鉴的只是“可选字段不应让主快照失败”和“成功刷新不得
保留过期库存”的状态处理。

### 7.4 CLI App Server RPC

学习单元：`CB-CODEX-04`

核心 RPC 位于
[`UsageFetcher.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/UsageFetcher.swift)。

启动命令等价于：

```text
/usr/bin/env <resolved-codex> -s read-only -a untrusted app-server
```

参数含义：

- `-s read-only`：沙箱策略只读；
- `-a untrusted`：审批策略不信任；
- `app-server`：启动换行分隔 JSON-RPC 服务。

调用序列：

```mermaid
sequenceDiagram
    participant App as CodexBar
    participant Proc as codex app-server
    App->>Proc: initialize {clientInfo}
    Proc-->>App: result
    App->>Proc: initialized notification
    App->>Proc: account/read
    Proc-->>App: account identity / plan
    App->>Proc: account/rateLimits/read
    Proc-->>App: windows / credits
    App->>Proc: terminate
```

| 方法 | 作用 |
|---|---|
| `initialize` | 声明 client name/version |
| `initialized` | 完成握手 |
| `account/read` | 读取账号身份与套餐 |
| `account/rateLimits/read` | 读取 rate windows 和 Credits |

超时：

- initialize：8 秒；
- 普通请求：3 秒；
- 超时任务会终止进程，不只是丢弃 continuation。

实现细节：

- stdout 是换行 JSON；
- `BoundedLineBuffer` 防止异常超长行无限占用内存；
- 单一 stdout 流上的请求串行处理；
- 跳过无 ID 的通知；
- 错误体如果内含可识别的 wham JSON，可尽量恢复有效数据；
- 最近启动失败会触发约 30 分钟 launch gate，避免持续尝试坏路径；
- 默认后台刷新每次建立短生命周期 App Server，不依赖常驻 session。

#### 与 QuotaView 的差异

QuotaView 当前：

- 直接启动 `<codex> app-server`；
- initialize timeout 和普通请求统一为默认 45 秒；
- 在同一长生命周期 actor 中复用连接；
- 并发请求 `account/rateLimits/read` 与 `account/usage/read`；
- 没有 `-s read-only -a untrusted` 参数；
- 还没有 RPC 行长度上限和启动失败 gate。

QuotaView 可优先学习：

1. 启动参数的只读/不信任约束，但必须先验证本机 Codex 版本兼容；
2. initialize 与普通请求分开超时；
3. stdout bounded buffer；
4. 进程超时时主动终止并允许下次重连；
5. App 退出时显式 stop；
6. 请求写入串行化和状态机测试。

QuotaView 不应直接照搬 3 秒普通超时。现有 Handoff 记录首次 Finder
请求可能需要 20–30 秒，应基于真实分位数设计“启动超时”和“已连接请求
超时”，而不是复制常数。

### 7.5 PTY `/status` 探针

学习单元：`CB-CODEX-05`

[`CodexStatusProbe.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/Providers/Codex/CodexStatusProbe.swift)
是手动诊断路径，不是默认后台数据源：

1. 通过 PTY 启动 Codex TUI；
2. 发送 `/status`；
3. 最长等待约 8 秒；
4. 解析失败时在约 4 秒边界重试；
5. 解析 Credits、5 小时、周/月限制和重置；
6. 识别 CLI update prompt；
7. 使用隔离工作目录和有界输出。

[`CodexCLISession.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/Providers/Codex/CodexCLISession.swift)
提供 actor 封装的持久 PTY：

- `openpty`；
- 记录可执行文件、参数、环境、工作目录和终端尺寸；
- 有界输出；
- 更新提示处理；
- 退出时先 SIGTERM，再必要时 SIGKILL 整个进程树。

QuotaView 已有稳定 App Server JSON-RPC，不应新增 PTY 作为常规路径。
PTY 只适合作为明确的 Debug/兼容性诊断功能，而且不能为了 UI QA 自动
触发。

### 7.6 Web Dashboard 补充数据

学习单元：`CB-CODEX-06`

CodexBar 的 OpenAI Web extras 默认关闭，因为它更耗电、依赖会话且容易
随页面变化。

主要实现位于
[`OpenAIWeb`](https://github.com/steipete/CodexBar/tree/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/OpenAIWeb)。

流程：

1. 主 Codex 获取先完成，以便确定当前账号 email；
2. 根据 email 生成确定性的 WebKit data store 标识；
3. 从配置的浏览器导入 ChatGPT/OpenAI cookie，或使用手动 cookie；
4. 先对 wham usage、`/backend-api/me`、`/api/auth/session` 做 API
   preflight；
5. 验证 Cookie 所属账号；
6. 必要时启动离屏 `WKWebView`；
7. 抓取 SPA 中 API 无法提供的 code review、history 和 Recharts 数据；
8. 用 refresh token/generation/account guard 防止旧账号结果发布；
9. 超时或内存压力时回收 WebView cache。

离屏窗口保留极小的可见交集和极低 alpha，避免 WebKit 对完全离屏页面
节流。这类实现成熟但成本很高。

QuotaView 的当前隐私承诺明确“不抓取网页、不读取登录凭据”，因此
`CB-CODEX-06` 应标为 **拒绝采用**，除非未来产品方向被用户明确改变。

### 7.7 本地成本扫描

学习单元：`CB-CODEX-07`

CodexBar 扫描已知 Codex JSONL、归档 session 和兼容 session root，
估算 token/cost，不做全盘文件系统搜索。

主要特征：

- 只扫已知目录；
- 1–365 天可配置窗口；
- 刷新最短间隔约 60 秒；
- 结果缓存到 `~/Library/Caches/CodexBar/cost-usage/...`；
- 网络无关；
- 与主 usage fetch 分离，避免大文件扫描阻塞菜单刷新。

QuotaView 当前 `account/usage/read` 已得到 lifetime 和 daily usage。
在这个接口足够时不应增加本地 session 扫描。未来如果需要模型级成本，
应作为独立、可关闭、低优先级的数据源。

---

## 8. 刷新、缓存与并发可靠性

### 8.1 批量刷新

学习单元：`CB-REFRESH-01`

[`UsageStore+Refresh.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/UsageStore%2BRefresh.swift)
负责批量刷新：

1. 阻止重复 batch 同时进入；
2. 计算需要显示和需要后台刷新的 Provider；
3. 使用 TaskGroup 并发执行各 Provider usage/status；
4. 主数据完成后执行 Credits、Web、cost 等 enrichment；
5. 发布 Store；
6. 写 Widget snapshot；
7. 调度下一次刷新或 reset boundary。

自动刷新在已有刷新进行时可以记录“完成后仍需再刷一次”，而不是简单
丢弃所有触发。

### 8.2 Provider Refresh Coordinator

学习单元：`CB-REFRESH-02`

[`ProviderRefreshCoordinator.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/ProviderRefreshCoordinator.swift)
提供按 key 协调：

- coalesce：复用当前有效请求；
- replace：取消旧请求并创建新 generation；
- invalidate：使所有进行中请求失去发布资格；
- waiter tracking：多个调用者等待同一 Task；
- waiter 取消不一定立即杀死仍被其他调用者等待的 Task；
- active count：可靠管理 `isRefreshing`；
- predecessor 等待和 retry-required。

### 8.3 发布上下文

学习单元：`CB-REFRESH-03`

请求开始时捕获：

- Provider generation；
- Provider 是否启用的 revision；
- Provider config revision；
- cost scope signature；
- 选中账号/owner identity；
- 是否允许 disabled Provider 发布。

请求完成时必须全部匹配才写入 Store。

```mermaid
sequenceDiagram
    participant UI
    participant Coord as Refresh Coordinator
    participant Fetch as Async Fetch
    participant Store

    UI->>Coord: begin generation 41, config rev 8
    Coord->>Fetch: fetch(context 41/8/account A)
    UI->>Coord: account changes to B, generation 42
    Coord-->>Fetch: cancel generation 41
    Fetch-->>Coord: generation 41 succeeds late
    Coord--xStore: reject stale publication
    Coord->>Fetch: fetch(context 42/9/account B)
    Fetch-->>Coord: generation 42 succeeds
    Coord->>Store: publish
```

仅调用 `Task.cancel()` 不够，因为底层网络、Process 或 callback 可能在取消
后仍返回。generation/revision 是第二道确定性防线。

### 8.4 错误与旧数据

学习单元：`CB-REFRESH-04`

CodexBar 区分：

- cancellation；
- timeout；
- DNS/断网/连接丢失；
- 暂时服务器错误；
- 首次无数据；
- 已有数据后的暂时失败；
- Provider 已知不提供 limit；
- Schema/解码异常；
- 凭据或账号错误。

成熟行为包括：

- 有旧数据时，第一次临时失败可由 `ConsecutiveFailureGate` 抑制；
- 第二次连续失败才明显呈现错误；
- 网络类失败保留旧 snapshot 并标 stale；
- “known limits unavailable” 不等同于网络失败；
- 新成功结果不能携带上次失败留下的旧可选数据；
- status API 短暂失败保留上一次有效 status；
- 取消不记作 Provider 业务错误。

### 8.5 启动和边界重试

学习单元：`CB-REFRESH-05`

启动网络恢复延迟大致为：

```text
15s → 45s → 120s → 300s
```

此外还会根据额度 reset boundary 单独安排刷新，避免只依赖固定周期导致
重置后显示旧数据。

### 8.6 自适应刷新

学习单元：`CB-REFRESH-06`

纯策略位于
[`AdaptiveRefreshPolicyCore.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/AdaptiveRefreshCore/AdaptiveRefreshPolicyCore.swift)。

固定提交的主要决策：

| 条件 | 间隔 |
|---|---:|
| Low Power 或 serious/critical thermal | 30 分钟 |
| 最近 5 分钟内打开菜单 | 2 分钟 |
| 菜单交互距今 5 分钟–1 小时 | 5 分钟 |
| 菜单交互距今 1–4 小时 | 15 分钟 |
| 无交互或超过 4 小时 | 30 分钟 |
| 明确同意 agent-aware 且近 5 分钟有编码活动 | 最慢收紧到 5 分钟 |

未来时间戳按最近交互处理，避免系统时钟变化导致极慢刷新。

固定 timer 以计划 tick 为锚点，刷新耗时不会让下一轮持续向后漂移；错过
多个 tick 时跳过旧 tick，不并发补跑。

进程/session 扫描只有在用户明确同意 agent-aware 模式时启用，而且只保留
最新活动时间，不保留完整活动内容。

### 8.7 QuotaView 优先改造

QuotaView 当前是每 60 秒：

```swift
while !Task.isCancelled {
    await refresh()
    sleep(60s)
}
```

这会使实际间隔变成“请求耗时 + 60 秒”，且进行中手动刷新直接被丢弃。

推荐分三步，不一次复制全部机制：

#### P0：结果发布守卫

- `refreshGeneration: UInt64`；
- refresh 开始捕获 generation；
- stop/restart、账号变化或影响数据的设置变化时 generation 递增；
- 成功和失败发布前检查 generation；
- App Server client reconnect 也绑定 generation。

#### P1：状态分类

定义类似：

```text
CodexFetchState
├── connecting
├── valid(snapshot, refreshedAt)
├── refreshing(previousSnapshot?)
├── stale(snapshot, reason, failedAt)
├── unavailable(reason)
└── failed(reason, previousSnapshot?)
```

UI 的“可用/不可用”仍严格表示最近一次 Codex 数据获取有效性，不得改成
CodexBar 的额度 ready/limited/exhausted 或服务事故状态。

#### P1：调度

- 以 scheduled tick 为锚；
- 首次连接可使用较长 timeout；
- 已连接请求用较短 timeout；
- 菜单打开后异步刷新，不阻塞面板显示；
- reset boundary 可触发一次额外刷新；
- 手动刷新可 replace 自动刷新。

#### P2：自适应

只有在能证明 60 秒固定轮询影响电量时再引入纯策略。QuotaView 单
Provider 的最低可行版本可以只有：

- 面板最近打开：1–2 分钟；
- 长时间未打开：5–15 分钟；
- Low Power：30 分钟；
- 手动刷新始终可用。

---

## 9. macOS 菜单栏与 UI 实现

### 9.1 Status Item

学习单元：`CB-MENUBAR-01`

[`StatusItemController.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/StatusItemController.swift)
是 `@MainActor` AppKit controller。

CodexBar 支持：

- 一个合并 `NSStatusItem`；
- 每 Provider 独立 `NSStatusItem`；
- 只有多个实际显示 Provider 且开启 merge 时才合并；
- Provider item 按需创建和删除；
- 每个 item 使用稳定 `autosaveName`，让 macOS 保留菜单栏位置。

QuotaView 已正确设置：

```swift
item.autosaveName = "QuotaView.StatusItem"
```

这一点已经无需改造。

### 9.2 菜单结构

学习单元：`CB-MENUBAR-02`

CodexBar 使用标准 `NSMenu`，其中混合：

- 原生 `NSMenuItem`；
- SwiftUI `NSHostingView` 卡片；
- Provider switcher；
- 账号 switcher；
- 原生 action；
- 刷新行、设置、退出。

菜单打开时：

1. 记录交互时间，供 adaptive refresh 使用；
2. 先立即显示现有数据；
3. 再异步刷新；
4. 不等待网络才弹出菜单。

菜单跟踪期间 AppKit 对结构变更敏感，因此部分 rebuild 被延迟到关闭后。

### 9.3 菜单复用与更新

学习单元：`CB-MENUBAR-03`

相关文件：

- [`StatusItemController+MenuSmartUpdate.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/StatusItemController%2BMenuSmartUpdate.swift)
- [`StatusItemController+MenuReconcile.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/StatusItemController%2BMenuReconcile.swift)
- [`StatusItemController+MenuCardRecycling.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/StatusItemController%2BMenuCardRecycling.swift)
- [`StatusItemController+MenuCardHeightCache.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/StatusItemController%2BMenuCardHeightCache.swift)

更新策略：

- 在 detached scratch `NSMenu` 中构建候选内容；
- 按行 shape、ID 和 view class 比较；
- 匹配的行原位更新；
- 只替换不匹配的中间区间；
- 缓存切走 Provider 的 tab 内容；
- 保存 highlight、viewport 和固定几何；
- 刷新 spinner 原位更新；
- HostingView 和测量高度复用。

这比每秒重建整个菜单更稳定，尤其能避免鼠标高亮丢失和菜单高度跳动。

### 9.4 图标与菜单栏文字

学习单元：`CB-MENUBAR-04`

[`IconRenderer.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/IconRenderer.swift)
在像素网格上绘制 template image，并根据：

- primary/weekly/credits；
- stale；
- incident；
- Provider style；
- 指示器；

生成图标。

优化方式：

- 数值量化后作为 cache key；
- 图标 LRU-like cache 约 64；
- morph cache 约 512；
- presentation signature 未变化时跳过重绘；
- loading animation 限帧且有最大持续时间。

菜单栏布局 token 支持 icon、name、account、session、weekly、bar、reset、
cost、separator、line break 等组合。缺少某个数值时显示破折号，不删除
旁边的布局 token。

### 9.5 QuotaView 应保留的差异

QuotaView 使用：

- `NSStatusItem`；
- borderless `NSPanel`；
- SwiftUI `NSHostingView`；
- 258 pt 固定宽度、动态高度；
- 单层原生 Liquid Glass；
- 自定义 Header/Footer/确认层；
- 不使用标准矩形 `NSMenu`。

这正是 QuotaView 已确定的产品语言。不能为了参考成熟项目而切换到
CodexBar 的 `NSMenu + hosting cards`。

可借鉴：

- 先显示后刷新；
- presentation signature；
- 避免无关 Store 字段触发 status item 重绘；
- 只更新图标/title 的变化部分；
- 面板打开期间避免无必要重建根 HostingView；
- stable `autosaveName`，QuotaView 已完成。

不要照搬：

- 多 Provider status items；
- Provider tab；
- 标准菜单矩形和系统阴影；
- CodexBar 卡片高度缓存体系；
- 与 QuotaView Figma 尺寸冲突的菜单间距和字体。

---

## 10. 设置窗口、通知、本地化与可访问性

### 10.1 设置窗口

学习单元：`CB-SETTINGS-01`

CodexBar 的设置窗口是原生 SwiftUI Settings Scene，主要入口：

[`PreferencesView.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/PreferencesView.swift)。

固定提交包含：

- General；
- Usage & Spend；
- Notifications；
- Menu Bar；
- Menu；
- Advanced；
- Hooks；
- About；
- Debug；
- 每个 Provider 的动态设置页。

窗口理想尺寸约 880×620，最小 800×540，Sidebar 260 pt。

这套设置规模服务于 63 Provider。QuotaView 已有独立的 872×637、
200 pt Sidebar 和系统语义表面规范，不能复制 CodexBar 尺寸或 pane
结构。

可以学习：

- pane selection 是可测试的枚举；
- Provider 设置由描述数据统一渲染；
- debug pane 只在明确启用时出现；
- 外观变化通过 AppKit bridge 修复窗口有效 appearance；
- 内容不足时滚动而不是压缩原生控件。

### 10.2 通知

学习单元：`CB-SETTINGS-02`

CodexBar 支持：

- 接近额度阈值；
- 额度重置；
- reset credits 临近过期；
- Provider incident；
- 可配置开关和阈值。

成熟要点：

- 通知基于状态“跨阈值”，不是每次刷新重复发送；
- 额度 identity 包含 Provider、账号和 limit 类型；
- 重置后清理旧告警状态；
- 可选数据缺失时不伪造通知；
- 系统权限申请和业务开关分离。

QuotaView 未来做额度提醒时，应先建立 `QuotaTransition`，避免简单写成
`remaining < 20` 就每分钟通知。

### 10.3 本地化和辅助功能

CodexBar 有多语言和 RTL 支持。业务文字通过本地化键；菜单、Tooltip、
通知和设置共享语义文案。

QuotaView 的 `AppCopy` 是更严格的当前规范，应继续作为唯一业务文字
来源。不能拷贝 CodexBar 的英文 label 直接进入 UI。

---

## 11. Provider 服务状态轮询

学习单元：`CB-STATUS-01`

CodexBar 的“status”是外部服务事故状态，不是数据抓取有效性。

[`UsageStore+Status.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/UsageStore%2BStatus.swift)
支持：

- statuspage.io `api/v2/summary.json` 和 components；
- incident.io grouped feed/proxy；
- Google Workspace incidents JSON；
- Provider metadata 中的 status page/link/product ID。

大 JSON 解码移出 MainActor，ISO8601 formatter 复用并加锁。

失败行为：

- 有旧 status 时保留；
- 没有旧数据时才显示 unknown；
- 事故 severity 可覆盖菜单栏图标。

### 11.1 QuotaView 的语义隔离

QuotaView 的状态标签按当前项目规范只能表示：

> 最近一次 Codex 数据获取是否有效。

它不能表示：

- 额度 ready/limited/exhausted；
- OpenAI status page 是否有事故；
- Credits 是否充足。

如果未来增加外部服务事故，只能作为独立字段/图标/说明，例如：

```text
dataAvailability = available / unavailable
serviceIncident = none / degraded / outage / unknown
quotaRisk = normal / warning / exhausted
```

三者不得合并成一个枚举或复用同一个“可用”徽标。

---

## 12. Widget、CLI 与辅助进程

### 12.1 Widget

学习单元：`CB-WIDGET-01`

共享模型见
[`WidgetSnapshot.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/WidgetSnapshot.swift)，
App 写入见
[`UsageStore+WidgetSnapshot.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/UsageStore%2BWidgetSnapshot.swift)。

设计：

- 主 App 获取数据；
- 只把 Widget 需要的最小 JSON 写入 App Group；
- Widget extension 只读；
- 不共享 token、cookie 或完整 Provider 响应；
- 主刷新和 token refresh 后更新快照；
- Widget timeline 对过密刷新做下限约束。

QuotaView Roadmap 已有 WidgetKit。未来实现时值得直接采用这个边界：

```text
QuotaView App → sanitized WidgetSnapshot JSON → App Group → Widget
```

不要让 Widget 单独启动 Codex App Server。

### 12.2 CLI

学习单元：`CB-CLI-01`

CodexBar CLI 复用 Core Fetch Plan，提供 Provider/source/credits/output 等
参数。它的价值是：

- 不重复数据解析；
- 便于自动化诊断；
- GUI 问题可用同一核心在终端复现；
- Linux target 能验证跨平台纯 Core。

QuotaView 已有只读 `QuotaViewProbe`，方向正确。后续应继续复用
`QuotaViewCore`，不要在 Probe 中重新解析另一套 schema。

### 12.3 Watchdog 和 Web Probe

Claude watchdog 负责 App 意外退出时清理 Provider 子进程；Web probe 用于
隔离诊断浏览器路径。

QuotaView 当前只有一个可控 App Server actor，优先做好 App 退出清理和
超时终止即可，不必增加独立 helper。只有发现真实孤儿进程问题且普通
termination handler 无法解决时才考虑 watchdog。

---

## 13. HTTP、安全、隐私与权限

### 13.1 通用 HTTP Client

学习单元：`CB-SEC-01`

[`ProviderHTTPClient.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/ProviderHTTPClient.swift)
提供：

- 默认 request timeout 约 30 秒；
- resource timeout 约 90 秒；
- 不无限等待 connectivity；
- 重定向守卫；
- 可注入 transport；
- 显式 retry policy。

携带凭据时的重定向只允许：

- HTTPS；
- 相同 HTTPS origin；
- 相同端口语义。

这防止 Authorization header 被跨域重定向带走。

默认不重试。对幂等 GET/HEAD/OPTIONS 可以选择最多一次 transient retry，
覆盖：

- 408；
- 429；
- 部分 5xx；
- 明确的临时 `URLError`。

退避和 `Retry-After` 有上限。

### 13.2 OAuth transport

学习单元：`CB-SEC-02`

OAuth transport 使用 ephemeral configuration：

- 不持久化 Cookie；
- 不使用共享 URL cache；
- 不使用系统 credential storage；
- redirect 同源约束；
- endpoint override 要求 HTTPS、无 userinfo、无编码分隔符；
- 只有明确场景允许 loopback HTTP。

### 13.3 Keychain

学习单元：`CB-SEC-03`

相关入口：

- [`KeychainSecurity.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/KeychainSecurity.swift)
- [`KeychainNoUIQuery.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/KeychainNoUIQuery.swift)
- [`KeychainAccessGate.swift`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/KeychainAccessGate.swift)

策略：

- 测试环境真实 Keychain fail closed；
- 后台查询使用 `LAContext.interactionNotAllowed`；
- 兼容旧系统的 UI-fail query policy；
- 用户可全局禁用 Keychain 访问；
- 浏览器 Cookie 自动导入默认保持狭窄范围；
- 不在不可预测的后台刷新中弹出 Keychain UI。

QuotaView 当前不读取凭据，因此不应引入 Keychain。若未来增加 OAuth 或
Cookie，必须先建立明确 consent、prompt 时机和测试禁用路径。

### 13.4 App Sandbox 与 Entitlements

CodexBar 主 App 未启用 App Sandbox，以访问 CLI、本地 session、浏览器
Cookie 和多个 Provider 运行时；主 entitlement 主要是 App Group。
Widget extension 启用 Sandbox 并只通过 App Group 读快照。

QuotaView 当前也因启动本机 Codex App Server 而未启用 App Sandbox。
“CodexBar 也未沙箱化”不能作为扩大权限的理由。每个新增文件、浏览器、
Keychain 或网络能力都应单独论证。

### 13.5 日志与敏感信息

CodexBar 有专门 redaction 工具，Widget 快照不含敏感身份认证信息。

QuotaView 后续诊断应继续只记录：

- 时间；
- 请求方法；
- 分类后的错误；
- 非敏感状态；
- 版本和耗时。

不要记录：

- raw JSON；
- Authorization；
- auth.json；
- Cookie；
- 完整账号身份；
- 可还原凭据的 stderr。

### 13.6 许可证

CodexBar 使用 MIT License。可以学习、修改和分发代码，但如果复制了
实质性源码，应保留其版权与 MIT 许可声明。架构思想和自行重写通常不等于
复制，但仍应在项目文档中保留参考来源。

---

## 14. 构建、发布和更新

学习单元：`CB-RELEASE-01`

CodexBar：

- SwiftPM 构建 Core、App、CLI 和 helper；
- Xcode project 构建 Widget extension；
- `Scripts/package_app.sh` 手工组装 `.app`；
- 嵌入 CLI、watchdog、Widget appex、Sparkle 和资源；
- 签名嵌套组件；
- Developer ID 使用 Hardened Runtime；
- 支持 universal 架构、notarization 和 release automation；
- Info.plist 注入版本、Build、Git 时间戳、Sparkle feed/public key；
- Debug、adhoc 或非 bundle 环境禁用真实 updater。

打包入口：

[`Scripts/package_app.sh`](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Scripts/package_app.sh)。

QuotaView 可学习：

- 构建元数据显式写入；
- nested component 逐层签名；
- updater 在不可信签名环境禁用；
- Release 中验证架构、版本、资源和签名；
- Widget 加入后由 Xcode target 构建并通过 App Group 隔离。

QuotaView 当前发布约束仍以本项目 `AGENTS.md` 和 `HANDOFF.md` 为准。

---

## 15. 测试设计

学习单元：`CB-TEST-01`

CodexBar 大量测试集中在以下边界：

- JSON/HTML/CLI 文本 fixture 解析；
- 新旧 Schema 和坏字段；
- Strategy 可用性与 fallback；
- HTTP status、redirect、timeout 和 retry；
- OAuth refresh 错误；
- config migration 和 normalization；
- identity/account ownership；
- generation/revision 发布资格；
- Task 取消和 waiter；
- stale cache 和连续失败；
- reset boundary 和虚拟时间；
- adaptive refresh 纯策略和 trace replay；
- 菜单模型、图标 key 和布局；
- Keychain 测试 fail-closed；
- Widget snapshot 编解码。

### 15.1 值得 QuotaView 补齐的测试

按优先级：

#### P0

- 老 refresh 在新 refresh 之后返回，不能覆盖新 snapshot；
- stop/reconnect 后旧 RPC continuation 不能发布；
- timeout 会清除 pending request 并终止坏进程；
- stdout 超长行会有界失败；
- invalid/partial `rateLimits` 不伪造 0%；
- optional `account/usage/read` 失败时主 rate limit 的处理策略明确；
- reset credit 从有到无时不能显示旧次数。

#### P1

- 首次启动慢与已连接请求的分离 timeout；
- 手动刷新替换自动刷新；
- 连续临时错误与 stale snapshot；
- App 退出时无残留 codex app-server；
- reset boundary 时间调度；
- `statusItemPresentationSignature` 仅在相关字段变化时改变。

#### P2

- Low Power/adaptive refresh 纯策略；
- Widget sanitized snapshot；
- 通知跨阈值去重。

测试不得读取真实 Keychain、真实 auth 文件或真实账号状态。

---

## 16. 成熟设计的优点、代价与风险

### 16.1 优点

#### 数据层可扩展

Provider descriptor、Strategy 和 Pipeline 把扩展点固定下来。新增服务不
需要改主刷新算法。

#### 对长期运行友好

避免无意义 UI rebuild、网络重试、进程风暴和 WebKit 泄漏，适合常驻
菜单栏应用。

#### 错误语义细

失败不会简单映射成“0%”或“没有额度”，显著降低误导用户的风险。

#### 账号归属严格

OAuth、CLI、Web 和历史数据只有在 identity 兼容时合并，避免多账号串数。

#### 可测试

Transport、环境、时间、存储和策略多数可注入，核心逻辑能脱离真实 UI 和
账号运行。

### 16.2 代价

#### 规模非常大

双 registry、大量 Store extension、Provider 专属设置和数十万行测试，
对单 Provider 工具明显过度。

#### 状态中心复杂

`UsageStore` 虽然分文件，但仍是大型聚合对象。理解一次状态发布可能需要
跨多个 extension。

#### Web/Cookie 路径维护成本高

浏览器、Keychain、WKWebView、页面脚本、账号匹配和内存管理形成一个
独立子系统。

#### 非沙箱主 App

多 Provider 能力依赖广泛本地访问，扩大攻击面和隐私解释成本。

#### 文档可能漂移

例如 Codex auto source 顺序。后续学习必须固定 commit 并以源码/测试
为准，不能只读 docs。

### 16.3 接口稳定性风险

以下均不是 QuotaView 可以假设永久稳定的公共契约：

- ChatGPT backend `/wham/*`；
- Codex App Server JSON-RPC schema；
- 浏览器 Dashboard DOM；
- Provider 私有/半公开 API；
- auth.json 和 config.toml 字段。

必须通过：

- 可损解码；
- unknown case；
- fixture；
- source labeling；
- 明确错误；
- 不伪造 0；

降低变化带来的用户误导。

---

## 17. QuotaView 采用矩阵

### 17.1 可直接采用

| 编号 | CodexBar 设计 | QuotaView 处理 | 优先级 |
|---|---|---|---|
| `QV-A01` | generation/revision 发布守卫 | 在 `CodexStatusStore` 增加轻量实现 | P0 |
| `QV-A02` | 取消与失败分类 | 建立 typed fetch error | P0 |
| `QV-A03` | 缺数据不显示 0 | 与现有破折号规范统一 | P0 |
| `QV-A04` | 退出显式清理进程 | Store stop + client stop | P0 |
| `QV-A05` | bounded line buffer | 加到 App Server stdout | P0 |
| `QV-A06` | 初始化/普通请求分离 timeout | 根据 QuotaView 实测设值 | P1 |
| `QV-A07` | 可选数据 enrichment | usage/token/reset credit 分离发布策略 | P1 |
| `QV-A08` | old snapshot + stale | 不把瞬时失败伪装成无数据 | P1 |
| `QV-A09` | reset boundary refresh | 独立一次性调度 | P1 |
| `QV-A10` | UI presentation signature | 减少 status item/面板无关刷新 | P1 |
| `QV-A11` | Widget 最小 App Group JSON | Roadmap 实现时采用 | P2 |
| `QV-A12` | 阈值通知状态机 | Roadmap 实现时采用 | P2 |

### 17.2 需要改造后采用

| CodexBar 设计 | 改造原因 |
|---|---|
| Provider Fetch Pipeline | QuotaView 单 Provider，只需 1–2 个 fetcher |
| 自适应刷新 | 先收集电量和刷新耗时，不复制全套活动扫描 |
| CLI timeout | QuotaView 首次启动可达 20–30 秒，不能照抄 3 秒 |
| 图标缓存 | QuotaView 图标状态较少，先用 signature，必要时再缓存 |
| 状态页事故 | 必须与“数据可用/不可用”分成独立语义 |
| 设置架构 | 保留 QuotaView 872×637、200 pt Sidebar 和系统表面 |
| OAuth 解析容错 | 只学习解码技巧，不读取 auth.json |
| App Server 启动参数 | 先验证各 Codex 版本对只读/审批参数的兼容 |

### 17.3 不应照搬

| CodexBar 设计 | 原因 |
|---|---|
| 63 Provider 双 registry | 对当前产品过度设计 |
| 标准 `NSMenu` 卡片体系 | 与 QuotaView 固定 Liquid Glass 面板冲突 |
| 多 Provider status items | 破坏专注、紧凑的单入口产品 |
| WebKit Dashboard 抓取 | 违反当前隐私和能耗方向 |
| 浏览器 Cookie/Keychain 导入 | 违反“不读取凭据”承诺 |
| 本地全量成本扫描 | 当前 App Server 数据已满足产品范围 |
| 外部 service incident 覆盖“可用”徽标 | 状态语义冲突 |
| reset consume/redeem | 当前绝对禁止；CodexBar 本身也未实现 |
| 原生 `NSPanel` 矩形阴影 | QuotaView 明确禁止 |
| CodexBar 字体、尺寸和颜色 | QuotaView Asta Sans/Figma/系统设置规范优先 |
| 自动展开、自动点击和截图 QA 路径 | QuotaView 验收边界明确禁止 |

---

## 18. 推荐的 QuotaView 演进顺序

### 阶段 A：可靠性底座

目标：不改变 UI 和隐私模型。

1. 给 `CodexAppServerClient` 加 bounded line buffer；
2. 分离 initialize/request timeout；
3. 给 `CodexStatusStore` 加 generation；
4. App 退出显式 stop；
5. 建立 typed error 和 publication test；
6. 部分 Schema 缺失不再在模型层默认成 0。

涉及参考：

- `CB-CODEX-04`
- `CB-REFRESH-02`
- `CB-REFRESH-03`
- `CB-REFRESH-04`
- `CB-TEST-01`

### 阶段 B：状态正确性

目标：数据异常时保持稳定、诚实的布局。

1. 分离有效、刷新中、stale、不可用、错误；
2. 主 rate limit 与 token usage 分别记录结果；
3. 可选请求失败不污染主状态；
4. 成功刷新清掉旧的可选库存；
5. 保持 `AppCopy` 和现有破折号语义。

涉及参考：

- `CB-CODEX-03`
- `CB-REFRESH-04`
- `CB-STATUS-01`

### 阶段 C：调度与能耗

目标：面板及时，后台克制。

1. 先显示缓存，再异步刷新；
2. timer 以计划 tick 为锚；
3. reset boundary refresh；
4. Low Power 下延长间隔；
5. 有数据后采样刷新耗时和失败率，再决定是否做 adaptive。

涉及参考：

- `CB-REFRESH-05`
- `CB-REFRESH-06`
- `CB-MENUBAR-02`

### 阶段 D：Roadmap 能力

目标：按真实产品需求扩展。

- Launch at Login：参考 `SMAppService.mainApp`；
- Widget：最小 App Group snapshot；
- 通知：跨阈值状态机；
- 更新：Sparkle + 签名环境 gate；
- 第二 Provider：确认产品方向后再引入轻量 Fetch Strategy。

---

## 19. 精确学习索引

后续任务可以直接引用下表编号。

| 学习编号 | 模块 | 首要源码 | 适合解决的问题 |
|---|---|---|---|
| `CB-APP-01` | App 生命周期 | `CodexbarApp.swift` | 启停、退出清理、全局协调 |
| `CB-STATE-01` | 设置与修订 | `SettingsStore.swift` | 配置持久化、revision |
| `CB-STATE-02` | 运行状态 | `UsageStore.swift` | Store 分层、观察面 |
| `CB-PROVIDER-01` | 注册表 | `ProviderDescriptor.swift` | Provider 完整性 |
| `CB-PROVIDER-02` | Fetch Context | `ProviderFetchPlan.swift` | 依赖和请求上下文 |
| `CB-PROVIDER-03` | Strategy/Pipeline | `ProviderFetchPlan.swift` | 数据源顺序和回退 |
| `CB-CODEX-01` | Codex source 选择 | `CodexProviderDescriptor.swift` | OAuth/CLI/Web 优先级 |
| `CB-CODEX-02` | OAuth usage | `CodexOAuthUsageFetcher.swift` | HTTP、token、可损解码 |
| `CB-CODEX-03` | 重置 Credits | `UsageStore+CodexResetCredits.swift` | 可选只读 enrichment |
| `CB-CODEX-04` | App Server RPC | `UsageFetcher.swift` | 进程、JSON-RPC、超时 |
| `CB-CODEX-05` | PTY probe | `CodexStatusProbe.swift` | 手动 CLI 诊断 |
| `CB-CODEX-06` | Web extras | `OpenAIWeb/*` | WebKit、Cookie、账号隔离 |
| `CB-CODEX-07` | 本地成本 | cost usage scanner | JSONL 成本估算 |
| `CB-REFRESH-01` | 批量刷新 | `UsageStore+Refresh.swift` | TaskGroup、enrichment |
| `CB-REFRESH-02` | 刷新协调 | `ProviderRefreshCoordinator.swift` | coalesce/replace/waiter |
| `CB-REFRESH-03` | 发布资格 | refresh extensions | 防旧结果覆盖 |
| `CB-REFRESH-04` | stale/error | refresh/error extensions | 失败后保留旧数据 |
| `CB-REFRESH-05` | 重试与边界 | startup/reset extensions | 启动重试、重置刷新 |
| `CB-REFRESH-06` | 自适应刷新 | `AdaptiveRefreshPolicyCore.swift` | 能耗和调度 |
| `CB-MENUBAR-01` | Status item | `StatusItemController.swift` | autosave、合并/独立 |
| `CB-MENUBAR-02` | 菜单生命周期 | `StatusItemController.swift` | 先显示后刷新 |
| `CB-MENUBAR-03` | 菜单增量更新 | MenuReconcile/Recycling | 防跳动和复用 |
| `CB-MENUBAR-04` | 图标 | `IconRenderer.swift` | 签名、量化、缓存 |
| `CB-SETTINGS-01` | 设置窗口 | `PreferencesView.swift` | pane、原生设置 |
| `CB-SETTINGS-02` | 通知 | notifier/transition files | 阈值去重 |
| `CB-STATUS-01` | Provider incident | `UsageStore+Status.swift` | 服务状态与数据状态隔离 |
| `CB-WIDGET-01` | Widget | `WidgetSnapshot.swift` | App Group 最小快照 |
| `CB-CLI-01` | CLI | `CodexBarCLI/*` | 共用 Core 和诊断 |
| `CB-SEC-01` | HTTP | `ProviderHTTPClient.swift` | redirect/retry/timeout |
| `CB-SEC-02` | OAuth transport | `CodexAuthenticatedHTTPTransport.swift` | ephemeral、同源 |
| `CB-SEC-03` | Keychain | `Keychain*.swift` | 无 UI 后台访问 |
| `CB-RELEASE-01` | 打包发布 | `Scripts/package_app.sh` | universal、签名、嵌套组件 |
| `CB-TEST-01` | 测试 | `Tests/*` | fixture、并发、时间 |

---

## 20. 关键源码入口

### 20.1 架构与入口

- [Package.swift](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Package.swift)
- [CodexbarApp.swift](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/CodexbarApp.swift)
- [UsageStore.swift](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/UsageStore.swift)
- [SettingsStore.swift](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/SettingsStore.swift)

### 20.2 Provider 与 Codex

- [Providers.swift](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/Providers/Providers.swift)
- [ProviderDescriptor.swift](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/Providers/ProviderDescriptor.swift)
- [ProviderFetchPlan.swift](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/Providers/ProviderFetchPlan.swift)
- [CodexProviderDescriptor.swift](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/Providers/Codex/CodexProviderDescriptor.swift)
- [Codex OAuth usage](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/Providers/Codex/CodexOAuth/CodexOAuthUsageFetcher.swift)
- [Codex token refresh](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/Providers/Codex/CodexOAuth/CodexTokenRefresher.swift)
- [Codex App Server RPC](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/UsageFetcher.swift)
- [Codex reset credit enrichment](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/UsageStore%2BCodexResetCredits.swift)

### 20.3 刷新与菜单

- [ProviderRefreshCoordinator.swift](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/ProviderRefreshCoordinator.swift)
- [UsageStore+Refresh.swift](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/UsageStore%2BRefresh.swift)
- [AdaptiveRefreshPolicyCore.swift](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/AdaptiveRefreshCore/AdaptiveRefreshPolicyCore.swift)
- [StatusItemController.swift](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/StatusItemController.swift)
- [Menu reconcile](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/StatusItemController%2BMenuReconcile.swift)
- [IconRenderer.swift](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBar/IconRenderer.swift)

### 20.4 安全、Widget 与发布

- [ProviderHTTPClient.swift](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/ProviderHTTPClient.swift)
- [KeychainNoUIQuery.swift](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/KeychainNoUIQuery.swift)
- [WidgetSnapshot.swift](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Sources/CodexBarCore/WidgetSnapshot.swift)
- [package_app.sh](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/Scripts/package_app.sh)
- [MIT License](https://github.com/steipete/CodexBar/blob/dd029db4cb17811edd5805d952c5d5fc23395be3/LICENSE)

---

## 21. 最终设计判断

CodexBar 是一个成熟的“多 Provider 状态聚合基础设施”；QuotaView 是一个
具有强视觉规范和清晰隐私承诺的“单 Codex 专注工具”。两者最合理的关系
不是产品形态复制，而是：

```text
保留 QuotaView 的产品与视觉
        +
吸收 CodexBar 的异步正确性、容错、安全和发布工程
```

后续任何借鉴都必须同时满足：

1. QuotaView 当前任务中的用户要求；
2. QuotaView 生产代码真实状态；
3. `HANDOFF.md`、`design-qa.md` 和 Figma 固定尺寸；
4. 不读取凭据、不抓取网页、不调用真实额度重置；
5. 不改变状态标签的数据有效性语义；
6. 不增加第二层玻璃或标准矩形菜单；
7. 没有用户视觉验收时继续标记“等待用户验收”。

这份文档适合做后续模块学习基线。上游 CodexBar 更新后，应新建带新 commit
的修订记录，不要静默把本文基线从 `dd029db` 改成浮动 `main`。
