# QuotaView workspace entry

This directory is a historical checkout. Current development lives in a separate worktree;
use its documentation and verify the checkout before building or editing.

- [Current project README](.worktrees/QuotaView-0.4.8/README.md) · [简体中文](.worktrees/QuotaView-0.4.8/README.zh-CN.md)
- [Development handoff](.worktrees/QuotaView-0.4.8/HANDOFF.md)
- [SDD registry](.worktrees/QuotaView-0.4.8/docs/specs/README.md)
- [Stable release and release history](.worktrees/QuotaView-0.4.8/VERSION_HISTORY.md#当前最新版本)
- [Archived README for this checkout](docs/archive/root-readme-en-2026-08-10.md)

See [AGENTS.md](AGENTS.md) for workspace routing. Historical build instructions and downloads
in the archive describe that checkout, not the current development source.
