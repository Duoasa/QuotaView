# QuotaView 工作区入口

此目录为历史 checkout，当前开发在独立工作区中。构建或修改前先从下列入口定位源码。

- [当前项目说明](.worktrees/QuotaView-0.4.8/README.zh-CN.md) · [English](.worktrees/QuotaView-0.4.8/README.md)
- [开发 Handoff](.worktrees/QuotaView-0.4.8/HANDOFF.md)
- [SDD 注册表](.worktrees/QuotaView-0.4.8/docs/specs/README.md)
- [公开稳定版与发布历史](.worktrees/QuotaView-0.4.8/VERSION_HISTORY.md#当前最新版本)
- [本 checkout 的历史 README](docs/archive/root-readme-zh-2026-08-10.md)

工作区路由见 [AGENTS.md](AGENTS.md)。归档里的构建步骤和下载版本只适用于当时，
不能作为当前开发源码或最新版本的依据。
