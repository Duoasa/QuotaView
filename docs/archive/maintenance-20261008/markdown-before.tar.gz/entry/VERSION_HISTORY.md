# QuotaView 版本历史入口

本目录是旧实验 checkout；完整发布事实由当前开发工作区维护。

## 当前最新版本

请以[公开稳定版与完整发布历史](.worktrees/QuotaView-0.4.8/VERSION_HISTORY.md#当前最新版本)
为准。开发版及未发布修改见[开发 Handoff](.worktrees/QuotaView-0.4.8/HANDOFF.md#工作区与版本定位)，
规格与验收阶段见[SDD 注册表](.worktrees/QuotaView-0.4.8/docs/specs/README.md)。
本页不另行维护 Latest、资产或开发版本号，避免形成第二份过期记录。

## 历史快照

[旧根 checkout 版本记录](docs/archive/root-version-history-2026-08-10.md)
完整保留原 0.3.1 及更早的发布内容；其中“当前最新”仅指当时状态。
