# 固定开发台 · 2026-09-30

固定编号：**2026-09-30-3s-sync-noise65**。用户要求“先将开发台固定在这个版本”。

这是现有独立 DEBUG 开发台的本地可恢复快照，不是生产发布或完整验收。冻结时运行 PID 为 35278；本次没有重新构建、重启、安装替换、提交或修改版本。

## 固定内容

- 整岛待确认辉光与选中卡片量子噪点共用 3 秒周期和相位。
- 外围辉光每轮约 0.6 秒完全熄灭；量子噪点最低保留 65% 亮度。
- 保留此前卡片、详情、十类确认 UI、按钮、连续滚动及全部 Demo 行为。
- 版本沿用 0.5.2 / 显示 Build 7 / 内部 48；这个版本号不是本快照的唯一标识，以上固定编号与 SHA256 才是。

## 文件

| 文件 | 用途 |
|---|---|
| [MultitaskIslandConsole.zip](MultitaskIslandConsole.zip) | 原 dist 应用包原样复制；可以解压恢复运行，不依赖临时运行目录 |
| [BuildInputs.zip](BuildInputs.zip) | 129 个构建输入的独立存档，保留根目录结构；包含开发台、依赖的生产源码/测试、包配置、字体与 Info.plist |
| [source-manifest.json](source-manifest.json) | 原应用内源码清单；与冻结时运行包完全一致 |
| [build-inputs-manifest.json](build-inputs-manifest.json) | 每个源码存档输入的 SHA256 |
| [baseline.json](baseline.json) | 固定时间、分支/HEAD、原运行位置、包身份及校验结论 |
| [SHA256SUMS](SHA256SUMS) | 所有固定资产与已有证据的校验值 |
| [evidence](evidence) | 上一轮构建、两项冒烟及交付记录；并非本轮重新测试 |

应用压缩包 SHA256：

~~~text
98b89e6a8ab91f5ec0d2e327f207019858c48567a834f5a264505c99e234a808
~~~

## 恢复和保护规则

1. 先在本目录执行 shasum -a 256 -c SHA256SUMS，核对原始资产。
2. 只恢复运行时，将 MultitaskIslandConsole.zip 解压到一个新的独立目录，打开其中的 Multitask Island Console.app。不要覆盖正式 QuotaView；不要同时保留多个开发台实例。当前实例正常运行时无需执行。
3. 需要未来修改时，把 BuildInputs.zip 解压到新目录后继续。原始生产源码只是开发台构建依赖快照，不代表授权替换正式工程。
4. 构建入口为解压目录下 Prototypes/MultitaskIslandConsole/build.sh。这是将来的重建入口，不是恢复原二进制的必要步骤；工具链与依赖版本变化时不保证重建包逐字节一致。
5. 本目录只读使用，不覆盖固定资产。未来经用户要求做下一版时，另建工作副本和新固定编号；禁止因文档里的历史“下一步”自动更新这里。

只做了归档完整性核验：运行包与存档主程序相同、源码清单一致、129 个输入逐项校验一致；没有新一轮 UI、通信或性能验收。当前运行进程未被干预。

