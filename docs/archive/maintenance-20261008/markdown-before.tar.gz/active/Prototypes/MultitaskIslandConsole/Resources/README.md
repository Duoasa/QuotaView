CodexAppIcon.png：来自本机 ChatGPT.app/Contents/Resources/icon-codex-light.png，仅用于隔离 DEBUG 开发台的来源标识；不迁入正式发布包。

CodexProviderIcon.png：来自本机 ChatGPT.app/Contents/Resources/icon-chatgpt.png，使用其 OpenAI 来源标识与可见 Vibe Island 参考对齐，仅用于隔离 DEBUG 开发台。
