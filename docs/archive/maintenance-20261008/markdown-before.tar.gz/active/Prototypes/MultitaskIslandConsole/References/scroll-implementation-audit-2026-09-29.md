# 刘海开发台滚动实现审查 · 2026-09-29

范围：隔离 `MultitaskIslandConsole` 的滚动、轨道、吸附、生命周期及相邻布局。先审查和清理并运行冒烟，再调整间距。用户本轮已确认前一版轨道可见；新间距仍待用户验收。

## 审查结论与处置

| 检查点 | 发现与处置 | 依据 |
|---|---|---|
| 实际运行版本 | 修改前源码与正在运行包的 console manifest 全部一致；生产源码相对前版和本轮基线 SHA-256 均未变化 | `baseline-production.json`、包内 manifest |
| 旧实现残留 | 原 `ConsoleVisibleScroller`、替换内置 scroller、负内距补偿、逐行位置 Preference 均已退出源码；当前只有独立轨道实现 | 源码搜索及本轮差异 |
| 滚动条所有权 | 旧 `.hidden` 可能被系统鼠标策略覆盖，代码又逐次强制设置 AppKit `hasVerticalScroller`，存在双重控制。现采用 `.never`，删除该设置及恢复逻辑；独立轨道继续提供拖动入口 | 官方 API 契约；legacy/overlay 样式下更新后卡片同宽冒烟 |
| 吸附状态 | 独立的 tracking/finger/momentum/sequence 标志维护成本高，改为互斥的 idle/native/finger/momentum/settling 状态；原生通知和滚轮阶段汇入同一状态机 | 惯性尾部、新手势接管、程序化详情定位、收起取消冒烟 |
| 监听与卸载 | 绑定原始 clip/document 对象，卸载时恢复其原通知标记；重复配置不重复安装监听，拆卸取消延迟任务，析构补充释放监听 | 20 次配置仍为 5 个通知观察和 1 个局部滚轮监听；拆卸后 0 个、无延迟回调，实例释放 |
| 布局常量 | 删除散落的宽度和补偿字面值，卡片内距、轨道位置与滑块宽度由 `ConsoleVibeLayout` 统一推导 | 完整刘海遮罩和实际宿主坐标的几何冒烟 |
| 绘制与性能 | 保留原生滚动与 CA 轨道绘制；没有恢复逐帧 SwiftUI 偏移或卡片测量 | 9 任务/120 次滚动基准；源码审查 |

滚动条策略依据：[Apple `.hidden` 文档](https://developer.apple.com/documentation/swiftui/scrollindicatorvisibility/hidden)、[Apple `.never` 文档](https://developer.apple.com/documentation/swiftui/scrollindicatorvisibility/never)。系统策略覆盖是确定的 API 行为；本轮未将其作为截图异常空白的唯一实机归因。

## 最终布局

- 展开宿主仍为 680 pt；凹角内缩后右边界 x=664。
- 有滚动时卡片左边 x=28、右边 x=642，宽 614 pt；滑块 x=650…656，两侧分别距卡片和岛体可见边缘 8 pt。
- 原生轨道命中区 14 pt，x=646…660；滑块 6 pt、深灰轨道 4 pt。仅超过四项显示。
- 轨道顶部与卡片区域顶部对齐，底部保留同一 8 pt 列表底距。行高 60 pt、行距 8 pt、字号及内联详情位置不变。

## 验证与边界

清理阶段 6 项冒烟通过后才调整布局；最终 6 项相关冒烟与 1 项基准通过。覆盖 4→11 项、虚拟刘海、两种系统滚动条样式、布局更新、原生动作转发、详情、展开/收起、筛选、惯性、取消和卸载。

9 任务/120 次离屏滚动：滚动/布局 P95 **5.22 ms**，主线程心跳 P95 **14.10 ms**，最大 **24.70 ms**，超过 33.33 ms 为 **0**。这不是 GPU 帧率或真实输入延迟。未进行完整回归或视觉自动化；真实鼠标/触控板手感及新间距由用户验收。

本轮限定范围未发现尚待修复的阻塞问题；验证结论不能扩展为全应用零缺陷保证。生产源码未改动，未提交、推送、发布或替换正式安装。

当前职责分配保持为：`ConsoleTaskScrollStops` 计算卡片位置；`ConsoleScrollGesture` 表达手势状态；`ConsoleTaskScrollProbe` 绑定原生容器、处理可取消吸附和可见性；弱引用 `ConsoleTaskScrollLink` 连接偏移与独立 `ConsoleTaskScrollRail`。没有额外滚动容器或第二套吸附实现。

证据目录：[`scroll-audit-20260929`](../.build/scroll-audit-20260929/)。其中包含源码差异 `source-changes.diff`、清理前基线、清理后冒烟、最终构建/检查、生产哈希和运行记录。新版 PID 50449：`/var/folders/zy/l0cfwlkd1gd9bnc1yh71bn0r0000gn/T/quotaview-scroll-audit-66y1nx4o/Multitask Island Console.app`；旧实例已按精确路径核对后关闭。
